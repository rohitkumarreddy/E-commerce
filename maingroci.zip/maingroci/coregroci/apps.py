from django.apps import AppConfig


class CoregrociConfig(AppConfig):
    name = 'coregroci'
