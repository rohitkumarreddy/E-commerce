from django.shortcuts import render
from django.http import JsonResponse
import json
from .models import *


# Create your views here.
def index(request):
    products= Product.objects.filter(Outofstock='False')[:8]
    if request.user.is_authenticated:
        customer = request.user.customer
        order,created = Order.objects.get_or_create(Customer=customer,complete=False)
        items=order.orderitem_set.all()
        #print(items)
    else:
        items=[]
        order={'get_cart_total':0,'get_cart_items':0}
    context={'products': products,'items':items,'order':order}
    return render(request, "coregroci/index.html",context)


def shop(request):
    products= Product.objects.all()
    if request.user.is_authenticated:
        customer = request.user.customer
        order,created = Order.objects.get_or_create(Customer=customer,complete=False)
        items=order.orderitem_set.all()
    else:
        items=[]
        order={'get_cart_total':0,'get_cart_items':0}
    context={'products': products,'items':items,'order':order}
    return render(request, "coregroci/shop.html",context)


'''def cart(request):
    if request.user.is_authenticated:
        customer = request.user.customer
        order,created = Order.objects.get_or_create(Customer=customer,complete=False)
        items=order.orderitem_set.all()
    else:
        items=[]
        order={'get_cart_total':0,'get_cart_items':0}
    context={'items':items,'order':order}
    return render(request, "coregroci/footer.html", context)'''


def checkout(request):
    if request.user.is_authenticated:
        customer = request.user.customer
        order,created = Order.objects.get_or_create(Customer=customer,complete=False)
        items=order.orderitem_set.all()
    else:
        items=[]
        order={'get_cart_total':0,'get_cart_items':0}
    context={'items':items,'order':order}
    return render(request, "coregroci/checkout.html",context)


# for deleting the product from the cart
def delete_item(request):
    data =json.loads(request.body)
    productId= data['productId']
    weight = data['selectedweight'] 
    #print(weight)
    customer = request.user.customer
    product = Product.objects.get(id=productId)
    order = Order.objects.get(Customer=customer, complete= False)
    orderItem = OrderItem.objects.get(order=order,product=product,weight=weight)
    orderItem.delete()
    return JsonResponse("item is deleted from cart",safe=False)


# adding the selected weight form the dropdown to serverside
'''def Quantity(request):
    data =json.loads(request.body)
    productId= data['productId']
    selectedweight=data['selectedweight']
    context={'productId':productId,'selectedweight':selectedweight}
    return JsonResponse("item quantity in shop",safe=False)'''

# for Updating the product in cart
def updateItem(request):
    data =json.loads(request.body)
    productId= data['productId']
    action= data['action']
    weight = data['selectedweight']
    #weight = request.GET['weights']
    customer = request.user.customer
    product = Product.objects.get(id=productId)
    order, created = Order.objects.get_or_create(Customer=customer, complete= False)
    orderItem,created = OrderItem.objects.get_or_create(order=order,product=product,weight = weight)
    if action== "add":
        #orderItem =OrderItem.objects.get(order=order,product=product,weight = weight)
        orderItem.quantity = (orderItem.quantity + 1)
    elif action == 'remove':
        #orderItem =OrderItem.objects.get(order=order,product=product,weight = weight)
        orderItem.quantity = (orderItem.quantity - 1)

    orderItem.save()

    if orderItem.quantity <= 0:
        orderItem.delete()
    return JsonResponse("item is added to cart",safe=False)

def about(request):
    if request.user.is_authenticated:
        customer = request.user.customer
        order,created = Order.objects.get_or_create(Customer=customer,complete=False)
        items=order.orderitem_set.all()
    else:
        items=[]
        order={'get_cart_total':0,'get_cart_items':0}
    context={'items':items,'order':order}
    return render(request, "coregroci/about.html",context)


def single(request,my_name):
    if request.user.is_authenticated:
        customer = request.user.customer
        order,created = Order.objects.get_or_create(Customer=customer,complete=False)
        items=order.orderitem_set.all()
    else:
        items=[]
        order={'get_cart_total':0,'get_cart_items':0}
    context={'items':items,'order':order}
    return render(request, "coregroci/shop.html",context)